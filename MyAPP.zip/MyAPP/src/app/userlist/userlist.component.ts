import { Component, OnInit } from '@angular/core';
import {UserService} from '../user.service';

@Component({
  selector: 'app-userlist',
  templateUrl: './userlist.component.html',
  styleUrls: ['./userlist.component.css'],
  template:`<h2>Userlist</h2>
             <table>
                   <tr>
                   <h3>{{errorMsg}}</h3>
                   </tr>
                   <tr>
                      <th>Name</th>   
     
                  </tr>
                  <tr *ngFor="let user of toDoArray">
                  <td>{{user.id}} . {{user.name}} . {{user.country}}</td>
     
                  </tr>
            </table>`
})
export class UserlistComponent implements OnInit {

 user=[];
 errorMsg:String;

  constructor(private _userservice:UserService) { }

  ngOnInit() {
   this._userservice.getUserService().subscribe(resUserData=>this.user=resUserData,
  repEmployeeError=>this.errorMsg=repEmployeeError);
  }

}
