import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-department',
 // templateUrl: './department.component.html',
  //styleUrls: ['./department.component.css']
  template:`<h3>DepartmentList</h3>
            <ul class="items">
            <li *ngFor="let department of departments">
            <span class="badge">{{department.id}}</span>{{department.name}}
            </li>
            </ul>`
})
export class DepartmentComponent  {

  //constructor() { }

 // ngOnInit() {
 // }

 departments=[
   {"id":1,"name":"Angular"},
   { "id":2,"name":"JAVA"},
   {"id":3,"name":"C"},
   {"id":4,"name":"C++"}
 ]
}
