import { Component } from '@angular/core';
import {UserService}  from './user.service';

@Component({
  selector: 'app-root',
  template:`<h1>userlist</h1>
             <nav>
             <a routerLink="/department" routerLinkActive="active">Department</a>
             <a routerLink="/employee" routerLinkActive="active">Employee</a>
             
             </nav>
             <app-department></app-department>
             `,
  //templateUrl: './app.component.html',
  //styleUrls: ['./app.component.css'],
  //providers:[UserService]
})
export class AppComponent {
 // title = 'app';
}
