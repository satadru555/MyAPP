import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { enableProdMode } from '@angular/core';
import { AppComponent } from './app.component';
import { UserlistComponent } from './userlist/userlist.component';
import {UserService}  from './user.service';
import {HttpModule}  from '@angular/http';

import { AppRoutingModule } from './app.routing.module';
import { routingComponents } from './app.routing.module';


@NgModule({
  declarations: [
    AppComponent,
    UserlistComponent,
    routingComponents
  ],
  imports: [
    BrowserModule,HttpModule,AppRoutingModule],

  providers: [UserService],
  bootstrap: [AppComponent]
})
export class AppModule { }
